package com.example.batch;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.example.models.ProductType1;

@Component
public class ProductItemType1Processor implements ItemProcessor<ProductType1,ProductType1>{
	
	@Override
	public ProductType1 process(ProductType1 product) throws Exception{
		//Items is getting processed.
		//Items are validated ..
		product.setClient(product.getClient().toUpperCase());
		product.setId(product.getId());
		product.setProductCode(product.getProductCode());
		product.setProductDescription(product.getProductDescription());
		product.setProductName(product.getProductName());
		product.setProductPrice(product.getProductPrice());
		return product;
	}
	
	
	
}
