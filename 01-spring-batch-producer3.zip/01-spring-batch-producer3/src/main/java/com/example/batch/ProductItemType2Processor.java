package com.example.batch;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.example.models.ProductType2;

@Component
public class ProductItemType2Processor implements ItemProcessor<ProductType2,ProductType2>{
	
	@Override
	public ProductType2 process(ProductType2 product) throws Exception{
		//Items is getting processed.
		//Items are validated ..
		product.setClient(product.getClient().toUpperCase());
		product.setId(product.getId());
		product.setProductCode(product.getProductCode());
		product.setProductDescription(product.getProductDescription());
		product.setProductName(product.getProductName());
		product.setProductPrice(product.getProductPrice());
		return product;
	}
	
	
	
}
