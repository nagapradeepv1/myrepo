package com.example.batch;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.batch.item.validator.ValidatingItemProcessor;
import org.springframework.stereotype.Component;

import com.example.models.Product;

@Component
public class ProductItemProcessor implements ItemProcessor<Product,Product>{
	
	@Override
	public Product process(Product product) throws Exception{
		//Items is getting processed.
		//Items are validated ..
		product.setClient(product.getClient().toUpperCase());
		product.setId(product.getId());
		product.setProductCode(product.getProductCode());
		product.setProductDescription(product.getProductDescription());
		product.setProductName(product.getProductName());
		product.setProductPrice(product.getProductPrice());
		return product;
	}
	
	
	
}
