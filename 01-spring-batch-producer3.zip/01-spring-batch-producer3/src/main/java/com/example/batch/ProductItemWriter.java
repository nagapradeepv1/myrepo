package com.example.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.example.models.Product;
import com.example.models.ProductType1;
import com.example.models.ProductType2;

@Component
public class ProductItemWriter implements ItemWriter<Product> {

	@Autowired
	private KafkaTemplate<String, Product> kafkaTemplate;

	@Override
	public void write(List<? extends Product> items) throws Exception {

		for (Product product : items) {

			// you can send to Kafka Topic

			System.out.println(product.getProductCode());
			System.out.println(product.getClient());
			System.out.println(product.getProductDescription());
			System.out.println(product.getProductName());
			System.out.println(product.getProductPrice());
			System.out.println(product.getId());
			if(product instanceof ProductType1) {
				System.out.println(((ProductType1)product).getClient1());

			}

			/*
			 * if (product.getClient().equalsIgnoreCase("amazon")) {
			 * kafkaTemplate.send("amazon.topic", product); } else if
			 * (product.getClient().equalsIgnoreCase("flipkart")) {
			 * kafkaTemplate.send("flipkart.topic", product); }
			 */
		}
	}

}
