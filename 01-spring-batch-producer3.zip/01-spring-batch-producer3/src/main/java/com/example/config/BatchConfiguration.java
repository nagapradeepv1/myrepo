package com.example.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.example.batch.ProductItemProcessor;
import com.example.batch.ProductItemType1Processor;
import com.example.batch.ProductItemType2Processor;
import com.example.models.Product;
import com.example.models.ProductType1;
import com.example.models.ProductType2;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private BatchConfigProperties batchConfigProperties;

	@Bean
	public Job job(ItemReader<Product> itemReader, ItemWriter<Product> itemWriter) {
		Step step = stepBuilderFactory.get("springBatchLoadStep").<Product, Product>chunk(3).reader(itemReader)
				.processor(classifierCustomerCompositeItemProcessor()).writer(itemWriter).build();
		
		return jobBuilderFactory.get("springBatchLoadJob").incrementer(new RunIdIncrementer()).start(step).build();
	}

	@Bean
	public FlatFileItemReader<Product> itemReader() {
		return new FlatFileItemReaderBuilder<Product>().name("FlatFileITemReader")
				.resource(new ClassPathResource(batchConfigProperties.getFileName()))
				.lineMapper(lineMapper()).linesToSkip(1).build();
	}
	
	@Bean
	public ClassifierCompositeItemProcessor<Product, Product> classifierCustomerCompositeItemProcessor() {
	    ClassifierCompositeItemProcessor<Product, Product> itemProcessor = new ClassifierCompositeItemProcessor<>();
	    
	    ProductItemType1Processor productItemType1Processor = new ProductItemType1Processor();
        ProductItemType2Processor productItemType2Processor = new ProductItemType2Processor();
        ProductItemProcessor productItemProcessor = new ProductItemProcessor();
	    
	    itemProcessor.setClassifier(new Classifier<Product, ItemProcessor<?, ? extends Product>>() {
	        @Override
	        public ItemProcessor<?, ? extends Product> classify(Product product) {
	        	if (product instanceof ProductType1) {
	        		return productItemType1Processor;
	        	}
	        	if (product instanceof ProductType2) {
	        		return productItemType2Processor;
	        	}
	        	return productItemProcessor;
	            
	        }
	    });
	    return itemProcessor;
	}

	public LineMapper<Product> lineMapper() {
		BeanWrapperFieldSetMapper<ProductType1> beanWrapperType1 = getBeanWrapperFieldSetMapper(ProductType1.class);
		BeanWrapperFieldSetMapper<ProductType2> beanWrapperType2 = getBeanWrapperFieldSetMapper(ProductType2.class);
	    Map<String, BeanWrapperFieldSetMapper> fieldSetMappers = new HashMap<String, BeanWrapperFieldSetMapper>();
	    fieldSetMappers.put("*typeitem1*", beanWrapperType1);
	    fieldSetMappers.put("*typeitem2*", beanWrapperType2);

	    
	    DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setDelimiter(",");
		lineTokenizer.setStrict(false);
		//to process Coa type 
		lineTokenizer.setNames(
				new String[] { "productCode", "productName", "productPrice", "productDescription", "client", "id","client1" });
		
		DelimitedLineTokenizer lineTokenizer1 = new DelimitedLineTokenizer();
		lineTokenizer1.setDelimiter(",");
		lineTokenizer1.setStrict(false);
		lineTokenizer1.setNames(
				new String[] { "productCode", "productName", "productPrice", "productDescription", "client", "id" });
		
		
		HashMap<String, DelimitedLineTokenizer> tokenizers = new HashMap<String, DelimitedLineTokenizer>();
	    tokenizers.put("*typeitem1*", lineTokenizer);
	    tokenizers.put("*typeitem2*", lineTokenizer1);
		    
		
	    PatternMatchingCompositeLineMapper patternMatchingCompositeLineMapper = new PatternMatchingCompositeLineMapper();
	    patternMatchingCompositeLineMapper.setFieldSetMappers(fieldSetMappers);
	    patternMatchingCompositeLineMapper.setTokenizers(tokenizers);
	    
	    return patternMatchingCompositeLineMapper;
		
	}
	
	private <T> BeanWrapperFieldSetMapper<T> getBeanWrapperFieldSetMapper(Class<T> targetType) {
		BeanWrapperFieldSetMapper<T> beanWrapperFieldSetMapper = new BeanWrapperFieldSetMapper<T>();
		beanWrapperFieldSetMapper.setTargetType(targetType);
		beanWrapperFieldSetMapper.setStrict(false);
		return beanWrapperFieldSetMapper;
	}

}
