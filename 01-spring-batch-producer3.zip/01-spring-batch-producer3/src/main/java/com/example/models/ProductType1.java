package com.example.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class ProductType1 extends Product{
	private String productDescription;
	private float productPrice;
	private String client;
	private String client1;
}
