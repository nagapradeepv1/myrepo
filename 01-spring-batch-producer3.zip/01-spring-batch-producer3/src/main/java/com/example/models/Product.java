package com.example.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class Product {
	private Integer id;
	private String productCode;
	private String productName;
 	private String productDescription;
 	private float productPrice;
	private String client;
}
